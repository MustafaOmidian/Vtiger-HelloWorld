<?php

$languageStrings = array(
    'Hello World' => 'سلام دنیا',
    'LBL_WELCOME' => 'یک سلام گرم به شما'
);