<?php
$languageString = array(
    'Hello World' => 'Hello World!',
    'LBL_WELCOME' => 'A very warm Welcom to you'
);